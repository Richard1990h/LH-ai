public class FixedFileResult
{
    public string FileName { get; set; } = string.Empty;
    public string FixedCode { get; set; } = string.Empty;
}
