namespace LittleHelperAI.Shared.Models
{
    public class WeatherConfig
    {
        public string WeatherApiKey { get; set; } = string.Empty;
    }
}
