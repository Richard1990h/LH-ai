namespace LittleHelperAI.Shared.Models;

public sealed class FixSyntaxResponse
{
    public string FixedCode { get; set; } = string.Empty;
}
