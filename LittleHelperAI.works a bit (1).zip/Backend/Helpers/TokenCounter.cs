using System.Text.RegularExpressions;

namespace LittleHelperAI.Backend.Helpers;

/// <summary>
/// Token counter for accurate credit deduction based on actual token usage
/// Uses approximate tokenization similar to OpenAI's token counting
/// </summary>
public static class TokenCounter
{
    private static readonly Regex WordPattern = new(@"\b\w+\b", RegexOptions.Compiled);
    private static readonly Regex SpecialTokenPattern = new(@"[^\w\s]", RegexOptions.Compiled);

    /// <summary>
    /// Estimate token count for a given text
    /// Approximation: ~4 characters = 1 token (OpenAI standard)
    /// </summary>
    public static int CountTokens(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return 0;

        // Count words
        var words = WordPattern.Matches(text).Count;
        
        // Count special characters (each is roughly 1 token)
        var specialChars = SpecialTokenPattern.Matches(text).Count;
        
        // Approximate: words + special chars + whitespace tokens
        // Average word length is ~4.7 chars, so roughly 1 token per word
        // Plus special characters
        var estimatedTokens = words + (specialChars / 2);
        
        // Minimum 1 token if text exists
        return Math.Max(1, estimatedTokens);
    }

    /// <summary>
    /// Count tokens in a conversation (prompt + response)
    /// </summary>
    public static (int promptTokens, int completionTokens, int totalTokens) CountConversationTokens(
        string prompt, 
        string response)
    {
        var promptTokens = CountTokens(prompt);
        var completionTokens = CountTokens(response);
        var totalTokens = promptTokens + completionTokens;

        return (promptTokens, completionTokens, totalTokens);
    }

    /// <summary>
    /// Calculate credit cost based on token usage
    /// </summary>
    /// <param name="totalTokens">Total tokens used</param>
    /// <param name="costPerToken">Cost per token from settings (default: 0.001)</param>
    public static double CalculateCreditCost(int totalTokens, double costPerToken = 0.001)
    {
        return totalTokens * costPerToken;
    }

    /// <summary>
    /// Calculate credit cost from conversation tokens
    /// </summary>
    /// <param name="prompt">The prompt text</param>
    /// <param name="response">The response text</param>
    /// <param name="costPerToken">Cost per token from settings (default: 0.001)</param>
    public static double CalculateCreditCostFromConversation(
        string prompt,
        string response,
        double costPerToken = 0.001)
    {
        var (_, _, totalTokens) = CountConversationTokens(prompt, response);
        return CalculateCreditCost(totalTokens, costPerToken);
    }
}
