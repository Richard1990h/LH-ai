using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LittleHelperAI.Shared.Models;
using LittleHelperAI.Backend.Helpers;
using LittleHelperAI.Models;
using LittleHelperAI.Data;
using LittleHelperAI.Backend.Services;
using LittleHelperAI.KingFactory;
using System.Text;
using System.Text.Json;

namespace LittleHelperAI.Backend.Controllers;

[ApiController]
[Route("api/chat")]
public class ChatController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly KnowledgeStoreService _knowledgeStore;
    private readonly CreditPolicyService _creditPolicy;
    private readonly IFactory _factory;

    public ChatController(
     ApplicationDbContext context,
     KnowledgeStoreService knowledgeStore,
     CreditPolicyService creditPolicy,
     IFactory factory)
    {
        _context = context;
        _knowledgeStore = knowledgeStore;
        _creditPolicy = creditPolicy;
        _factory = factory;
    }

    private static string NormalizeQuestion(string input)
    {
        return input
            .Trim()
            .ToLowerInvariant()
            .Replace("?", "")
            .Replace(".", "")
            .Replace(",", "");
    }

    private static readonly JsonSerializerOptions _jsonOpts = new()
    {
        PropertyNameCaseInsensitive = true
    };

    private static ChatTranscript LoadTranscript(ChatHistory chat)
    {
        if (string.IsNullOrWhiteSpace(chat.Metadata))
            return new ChatTranscript();

        try
        {
            var transcript = JsonSerializer.Deserialize<ChatTranscript>(chat.Metadata, _jsonOpts);
            if (transcript?.Turns != null)
                return transcript;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[ChatController] LoadTranscript deserialization failed for chat {chat.Id}: {ex.Message}");
        }

        return new ChatTranscript();
    }

    private static void SaveTranscript(ChatHistory chat, ChatTranscript transcript)
    {
        chat.Metadata = JsonSerializer.Serialize(transcript, _jsonOpts);
    }

    [HttpPost("send")]
    [RequestSizeLimit(52428800)]
    public async Task<IActionResult> Send([FromBody] ChatRequest request)
    {
        if ((string.IsNullOrWhiteSpace(request.Message) && (request.Files == null || !request.Files.Any()))
            || request.UserId <= 0)
            return BadRequest("Invalid request.");

        var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == request.UserId);
        if (user == null)
            return Unauthorized();

        var rawMessage = (request.Message ?? "").Trim();
        var hasFiles = request.Files != null && request.Files.Any();
        var normalizedKey = NormalizeQuestion(rawMessage);

        ChatHistory chat;
        if (request.CreateNewChat)
        {
            chat = new ChatHistory
            {
                UserId = user.Id,
                Message = "",
                Reply = "",
                Title = rawMessage.Length > 50 ? rawMessage[..47] + "..." : rawMessage,
                Timestamp = DateTime.UtcNow
            };
            _context.ChatHistory.Add(chat);
        }
        else
        {
            if (!request.ChatId.HasValue || request.ChatId.Value <= 0)
                return BadRequest("ChatId is required to continue conversation.");

            var foundChat = await _context.ChatHistory
                .FirstOrDefaultAsync(c => c.Id == request.ChatId.Value && c.UserId == user.Id);

            if (foundChat == null)
                return BadRequest("Invalid ChatId");

            chat = foundChat;
        }

        var transcript = LoadTranscript(chat);
        transcript.Turns.Add(new ChatTurn
        {
            Role = "user",
            Text = rawMessage,
            Utc = DateTime.UtcNow
        });

        // Initialize factory if not ready
        if (!_factory.IsReady)
        {
            try
            {
                await _factory.InitializeAsync();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = $"Failed to initialize AI: {ex.Message}" });
            }
        }

        // Process through Factory with tools enabled
        var responseBuilder = new StringBuilder();
        var options = new FactoryOptions
        {
            EnableTools = true,
            EnableReasoning = true,
            EnableValidation = true
        };

        try
        {
            await foreach (var output in _factory.ProcessInConversationAsync(
                chat.Id.ToString(),
                rawMessage,
                options))
            {
                if (output.Type == FactoryOutputType.Token)
                {
                    responseBuilder.Append(output.Content);
                }
                else if (output.Type == FactoryOutputType.Complete && !string.IsNullOrEmpty(output.Content))
                {
                    responseBuilder.Append(output.Content);
                }
                else if (output.Type == FactoryOutputType.Error)
                {
                    responseBuilder.AppendLine($"\n[Error: {output.Content}]");
                }
                else if (output.Type == FactoryOutputType.ToolResult)
                {
                    responseBuilder.AppendLine($"\n[Tool Result: {output.Content}]");
                }
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { error = $"AI processing failed: {ex.Message}" });
        }

        string reply = responseBuilder.ToString();
        if (string.IsNullOrWhiteSpace(reply))
        {
            reply = "[No response generated]";
        }

        transcript.Turns.Add(new ChatTurn
        {
            Role = "assistant",
            Text = reply,
            Utc = DateTime.UtcNow
        });

        SaveTranscript(chat, transcript);

        chat.Message = rawMessage;
        chat.Reply = reply;
        chat.Timestamp = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        return Ok(new
        {
            Message = reply,
            MessageId = chat.Id,
            used = 0,
            creditsLeft = user.Credits,
            tokens = 0
        });
    }

    [HttpGet("history/{userId}")]
    public async Task<IActionResult> GetHistory(int userId)
    {
        var messages = await _context.ChatHistory
            .Where(m => m.UserId == userId)
            .OrderByDescending(m => m.Id)
            .Take(50)
            .Select(m => new ChatSummary
            {
                Id = m.Id,
                Title = m.Title,
                Timestamp = m.Timestamp
            })
            .ToListAsync();

        return Ok(messages);
    }

    [HttpGet("load/{chatId}")]
    public async Task<ActionResult<List<ChatMessageDto>>> LoadChatById(int chatId)
    {
        var chat = await _context.ChatHistory
            .AsNoTracking()
            .FirstOrDefaultAsync(c => c.Id == chatId);

        if (chat == null)
            return NotFound();

        var messages = new List<ChatMessageDto>();

        if (!string.IsNullOrWhiteSpace(chat.Metadata))
        {
            try
            {
                var transcript = JsonSerializer.Deserialize<ChatTranscript>(
                    chat.Metadata,
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true }
                );

                if (transcript?.Turns != null && transcript.Turns.Count > 0)
                {
                    foreach (var turn in transcript.Turns)
                    {
                        messages.Add(new ChatMessageDto
                        {
                            IsUser = turn.Role == "user",
                            Text = turn.Text,
                            Timestamp = turn.Utc
                        });
                    }
                    return Ok(messages);
                }
            }
            catch { }
        }

        messages.Add(new ChatMessageDto
        {
            Text = chat.Message ?? string.Empty,
            IsUser = true,
            Timestamp = chat.Timestamp
        });

        if (!string.IsNullOrWhiteSpace(chat.Reply))
        {
            messages.Add(new ChatMessageDto
            {
                Text = chat.Reply,
                IsUser = false,
                Timestamp = chat.Timestamp
            });
        }

        return Ok(messages);
    }

    [HttpDelete("delete/{chatId}")]
    public async Task<IActionResult> DeleteChat(int chatId, [FromQuery] int userId)
    {
        if (userId <= 0)
            return BadRequest("Invalid user");

        var chat = await _context.ChatHistory
            .FirstOrDefaultAsync(c => c.Id == chatId && c.UserId == userId);

        if (chat == null)
            return NotFound();

        _context.ChatHistory.Remove(chat);
        await _context.SaveChangesAsync();

        return Ok(new { success = true, deletedChatId = chatId });
    }
}
