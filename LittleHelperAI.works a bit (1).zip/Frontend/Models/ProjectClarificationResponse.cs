public sealed class ProjectClarificationResponse
{
    public bool NeedsClarification { get; set; }
    public string? Message { get; set; }
}
